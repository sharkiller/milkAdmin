/**
	milkAdmin - WebAdministrator of Minecraft Server for Bukkit
    Copyright (C) 2010-2011  Alejandro Barreiro (Sharkiller)
**/
/*	
    This file is part of milkAdmin.

    This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
	To view a copy of this license, visit http'://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to
	Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
*/

///////////////////////////////////////////////
//
//   Language for index.html
//
///////////////////////////////////////////////

var langIndex = {
	///////////////////
	//	Common
	///////////////////
	'lang1Yes': "Ja",
	'lang1No': "Nee",
	'lang1OK': "Ok",
	'lang1Add': "Voegtoe",
	'lang1Cancel': "Annuleren",
	'lang1Send': "Versturen",
	'lang1Change': "Veranderen",
	'lang1On': "Aan",
	'lang1Off': "Uit",
	'lang1ReloadList': "Lijst herladen",
	'lang1IPAddress': "IP Adres",
	'lang1Player': "Speler",
	'lang1Action': "Actie",
	'lang1User': "Gebruikersnaam",
	'lang1Password': "Wachtwoord",
	///////////////////
	//	Header
	///////////////////
	'langAbout': "Over",
	'langLogout': "Utloggen",
	'langChooseLanguage': "Kies een taal",
	'langTranslate': "Vertaalt naar uw taal",
	///////////////////
	//	Update Dialog
	///////////////////
	'langNewVersionAvailable': "Nieuwe versie verkrijgbaar",
	'langVersionAvailable': "milkAdmin v_VER_ is available", // milkAdmin v1.0 is available
	'langUpdateNow': "Wil je nu updaten?",
	///////////////////
	//	About Dialog
	///////////////////
	'langmilkAdmin': "Over MilkAdmin",
	'langDesign': "Ontwerp en Programmering:",
	'langUpdates': "Update",
	'langThanks': "Met Dank aan:",
	///////////////////
	//	Ban Dialog
	///////////////////
	'langBanOptions': "Ban opties",
	'langKickPlayer': "Kick Speler",
	'langBanPlayerName': "Ban Speler Naam",
	'langBanIPAddress': "Ban IP Adres",
	'langCause': "Oorzaak/omdat",
	///////////////////
	//	Main Menu
	///////////////////
	'langRestartServer': "Server herstarten",
	'langReloadServer': "Server herladen",
	'langBackupStart': "Start Back-up",
	'langSaveMap': "Wereld saven",
	'langStopServer': "Server stoppen",
	///////////////////
	//	Sub Menu
	///////////////////
	'langServerSM': "Server",
	'langConsoleSM': "Console",
	'langPluginsSM': "Plugins",
	'langBackupsSM': "Backups",
	'langPlayersSM': "Spelers",
	'langBanListSM': "Banlist",
	'langWhitelistSM': "Witlijst",
	///////////////////
	//	Server Info
	///////////////////
	'langLastRestart': "Laatste Herstart",
	'langAmountPlayersOnline': "Nummers van de players online",
	'langFreeMemory': "Gratis Geheugen",
	'langUsedMemory': "Gebruikt Geheugen",
	'langTotalMemory': "Totaal Geheugen",
	'langMaxMemory': "Maximaal Geheugen",
	'langTitleMemory': "Geheugen Gegevens- <b>Beschikbare Geheugen</b>: laat de overige beschikbare geheugen zien die over is voor de Minecraft Server.<br><b>Gebruikte Geheugen</b>: Laat de gebruikte geheugen zien Minecraft Server.<br><b>Totaal Geheugen</b>: Laat de totaal geheugen van de server zien.<br><b>Maximale Geheugen</b>: Laat zien wat de maximale geheugen is wat de minecraft server kan gebruiken.",
	'langFreeSpace': "Beschikbare Ruimte",
	'langUsedSpace': "Gebruikte Ruimte",
	'langTotalSpace': "Totaal gebruikte ruimte",
	'langTitleSpace': "Space Data - Based on &quot;Backup Folder&quot; directory.",
	'langServerVersion': "Server Versie",
	'langCraftbukkitBuild': "CraftBukkit Versie",
	///////////////////
	//	Server Panel
	///////////////////
	//	Server Info
	///////////////////
	'langServerInfoSM': "Server Informatie",
	'langBroadcastMessage': "Uitgezonden Bericht",
	'langTitleBroadcastMessage': "Uitgezonden Bericht - Verzonden naar alle spelers zonder tag",
	'langLevelName': "Standaard Level Name",
	'langTitleLevelName': "The value will be used as world name and as folder name.<br>You may also copy your saved game folder here, and change the name to the same as that folder\'s to load it instead. ",
	'langMCIPPORT': "Minecraft Server IP and Port",
	'langTitleMCIPPORT': "<b>IP:</b> Set this if you want the server to bind to a particular IP. It is strongly recommended that you leave server-ip blank!<br><b>Port:</b> Changes the port the server is hosting on. This port must be forwarded if the server is going through a router.<br><b>Valid values:</b><ul><li><b>IP:</b> Blank, or the IP you want your server to run on.</li><li><b>Port:</b> A number between <b>1-65535</b>. Default: <b>25565</b><ul><li>Should be greater than 20000 to avoid conflicts with system reserved ports.</li></ul></li></ul>",
	'langMaxPlayers': "Max Players",
	'langTitleMaxPlayers': "The max numbers of players that can play on the server at the same time.<br><i>Note that if more players are on the server it will use more resources.</i><br><i>Note also, admin connections are not counted against the max players.</i><br><b>Valid values:</b><ul><li>A number between <b>0-255</b>.</li></ul>",
	'langViewDistance': "View Distance",
	'langTitleViewDistance': "The amount of chunks the server sends to the players.<br><b>Valid values:</b><ul><li>A number between <b>3-15</b>. Default: <b>10</b></li></ul>",
	'langHoldMessage': "Hold Message",
	'langTitleHoldMessage': "Message that MCSODRTK will display when Server is on Hold.<br><i>Needs MinecraftRemoteToolkit</i>",
	'langAllowNether': "Allow Nether",
	'langTitleAllowNether': "Allows players to travel to the Nether.<ul><li><b>true</b> = The server will allow Portals to send players to the Nether.</li><li><b>false</b> = Portals will not travel to the Nether.</li></ul>",
	'langSpawnMonsters': "Spawn monsters",
	'langTitleSpawnMonsters': "Set true if you want monsters to be spawned at night, false if you don\'t.<br><i>Tip: if you have major lag, turn this off.</i><ul><li><b>true</b> = Monsters will appear at night and in the dark.</li><li><b>false</b> = No monsters.</li></ul>",
	'langSpawnAnimals': "Spawn Dieren",
	'langTitleSpawnAnimals': "Animals will be able to spawn.<ul><li><b>true</b> = Animals spawn as normal.</li><li><b>false</b> = Animals will immediately vanish.</li></ul>",
	'langOnlineMode': "Online modus",
	'langTitleOnlineMode': "Server checks connecting players against minecraft\'s account database.<br>Only set this to false if your server is not connected to the Internet.<ul><li><b>true</b> = The server will assume it has an Internet connection and check in minecraft.net every connecting player.</li><li><b>false</b> = The server will not attempt to check connecting players.</li></ul>",
	'langPVP': "Speler vs Speler (SvS)",
	'langTitlePVP': "Enable Player vs Player on the server.<br><i>Note: Hitting a player while having PvP set to false and having tamed wolfs will still cause the wolfs<br>attacking the attacked player.</i><ul><li><b>true</b> = Players will be able to kill each other.</li><li><b>false</b> = Players cannot kill other players.</li></ul>",
	'langAllowFlight': "Vlucht Toestaan",
	'langTitleAllowFlight': "Will allow users to use flight/no-clip on your server, if they have an mod that provides flight/no-clip installed.<ul><li><b>true</b> = Flight/no clip is allowed, and used if the player have a no-clip mod installed.</li><li><b>false</b> = Flight/no-clip is not allowed.</li></ul>",
	'langWhitelist': "Witlijst",
	'langTitleWhitelist': "Enable a white list on the server. With a white list enabled, users not on the white list will be unable to connect.<ul><li><b>true</b> = The file white-list.txt is used to generate the white list.</li><li><b>false</b> = No white list is used.</li></ul>",
	///////////////////
	//	Whitelist
	///////////////////
	'langWhitelistSM': "Witlijst",
	'langWLAddPlayer': "Voeg speler toe",
	'langWLDeleteSelected': "Verwijder geslecteerde",
	'langWLSaveChanges': "Sla Verandering op",
	///////////////////
	//	Plugin Panel
	///////////////////
	'langEnablePlugin': "Zet plugin aan",
	'langEnable': "Zet aan",
	'langPluginName': "Plugin naam",
	'langVersion': "Versie",
	'langReloadTheList': "Herlaad de lijst",
	///////////////////
	//	Backup Panel
	///////////////////
	'langChooseYourBackup': "Kies je backup",
	'langRestoreBackup': "Herstoor Backup",
	'langDeleteBackup': "Verwijder Backup",
	'langBackupClear': "Verwijder vorige mappen voordat je een backup terug zet",
	///////////////////
	//	Players
	///////////////////
	'langUserManagement': "Gebruikers managment",
	'langIP': "IP",
	'langPort': "Poort",
	'langKill': "Moord",
	'langKick': "Kick",
	'langBanName': "Ban",
	'langBanIP': "Ban IP",
	'langAmount': "Hoeveelheden of Keer",
	'langShootArrow': "Schiet pijl",
	'langShootFireball': "Schiet Vuurbal",
	'langThrowEgg': "Gooi ei",
	'langThrowSnowball': "Teleport naar Speler",
	'langTeleportToPlayer': "Telepoort naar speler",
	'langTeleportToCoord': "Telepoort naar Coord",
	'langChangeName': "Verander Naam",
	///////////////////
	//	Ban List
	///////////////////
	'langCreateBan': "Ban IP adress of naam",
	'langClearFilter': "Maak Filte schoon",
	///////////////////
	//	milkAdmin
	///////////////////
	'langRegisterAdmin': "Registreet een nieuwe admin",
	'langCreateAdmin': "Kreeeer admin"
};

var jsIndex = {
	'sProcessing': "Verwerken",
	'sLengthMenu': "Laat Menu plugins zien", // Show 10 plugins
	'sZeroRecords': "Geen plugins gevonden",
	'sInfo': "Weergeven_START_->_EINDE_of_TOTAAL_plugins", // Showing 1->10 of 17 plugins
	'sInfoEmpty': "Geen plugins beschikbaar",
	'sInfoFiltered': "Filter of Maximale plugins", // (filter of 17 plugins)
	'sSearch': "Zoek Plugin",
	'sFirst': "Eerst",
	'sPrevious': "Vorige",
	'sNext': "Volgende",
	'sLast': "Laatste",
	'ReloadServer': "Server opnieuw aan het herladen",
	'RestartServer': "Server aan het herstarten",
	'StopServer': "Server aan het Stoppen",
	'EnablePlugin': "Plugin Geactiveerd!",
	'StartBackup': "Maakt Backup",
	'RTKNeeded': "You need the RemoteToolkit to use this function!",
	'NoUsersOnline': "Geen spelers online",
	'NoBackups': "Er is geen backup",
	'activate': "Geactiveerd",
	'deactivate': "Deactiveerd",
	'unban': "Unbannen",
	'MustLogin': "You must login!",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'InvalidIP': "Ongeldige IP Adres",
	'UpdateNow': "Update Nu",
	'later': "Later"
};

var jsAjax = {
	'accountcreated': "Account Gemaakt!",
	'worldsaved': "Wereld Opgeslagen!",
	'messagesent': "Bericht Verzonden",
	'broadcastedmessage': "Uitgezonden Bericht",
	'forcestop': "Snelle Stop",
	'plugindisabled': "_NAAM_\'s plugin uitgezet", // PluginX's plugin disabled.
	'pluginenabled': "_NAAM_\'s plugin geactiveerd", // PluginX's plugin enabled.
	'editedproperty': "Bewerk Goed",
	'worldbackedup': "Back-up Wereld",
	'deletebackup': "Back-up Verwijderd",
	'kickplayer': "_NAAM_ is van de server verstoten", // Sharkiller kicked from the server
	'itemsgiven': "_NAME_ is gegeven _amount_ getal of _item_", // Sharkiller was given 64 units of IRON
	'itemsremoved': "_NAME_ removed _AMOUNT_ units of _ITEM_", // Sharkiller removed 64 units of TNT
	'playerkilled': "_NAME_ is vermoord", // Sharkiller killed
	'healthchanged': "_NAME_\'s hp is veranderd naar _AMOUNT_/20", // Sharkiller's health changed to 5/20
	'playerbanned': "_NAME_ was banned!", // Sharkiller was banned!
	'playerunbanned': "_NAME_ was unbanned!", // Sharkiller was unbanned!
	'ipbanned': "_IP_ is verbannen", // 19.64.84.24 was banned!
	'ipunbanned': "_IP_ is ongebannen", // 19.64.84.24 was unbanned!
	'arrowshooted': "Boog schot", 
	'fireballshooted': "Vuurbal Geschoten", 
	'throwsnowball': "Sneeuwball gegooit",
	'throwegg': "Ei gooien",
	'changename': "_OLD_\'s name changed to _NEW_", // Sharkiller's name changed to Peter
	'playerteleported': "Speler is getransporteerd ",
	'langchanged': "Taal veranderd! Herladen Pagina ",
	'wlloaded': "Whitelist loaded!",
	'wladded': "Toegevoegt aan de Whitelist",
	'wlsaved': "Whitelist Is sucsessvol opgeslagen",
	///////////////////
	//	Errors
	///////////////////
	'badparameters': "Verkeerde Parameters",
	'messageempty': "Lege Bericht",
	'wladdfail': "Failed to add player to Whitelist!",
	'wlsavefail': "Failed to save Whitelist! Try again!",
	'playernotconnected': "Speler is niet verbonden",
	'playernotbanned': "Speler is niet verbannen",
	'ipnotbanned': "IP is niet verbannen",
	'langnotfound': "Taal niet gevonden!"
};

///////////////////////////////////////////////
//
//   Language for login.html
//
///////////////////////////////////////////////

var langLogin = {
	'langmilkAdminLogin': "Login in milkAdmin",
	'langUsername': "Gebruikersnaam",
	'langPassword': "Wachtwoord",
	'langLogin': "Login"
};

var jsLogin = {
	'welcome': "Welkom! Pagina aan het Laden...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'invalidlogin': "Ongeldige Gebruikersnaam of Password!"
};

///////////////////////////////////////////////
//
//   Language for register.html
//
///////////////////////////////////////////////

var langRegister = {
	'langCreateAnAccount': "Maak een Account",
	'langUsername': "Gebruikersnaam",
	'langPassword': "Wachtwoord",
	'langCreateAccount': "Maak account"
};

var jsRegister = {
	'created': "Account Gemaakt! Pagina Laden",
	'notadmin': "Je kan niet \"admin\" als gebruikersnaam gebruiken",
	'baduser': "A.U.B voer een geldige gebruikersnaam en password in",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'error': "Ongeldige Gebruikersnaam en/of Password"
};

///////////////////////////////////////////////
//
//   Language for startServer.html
//
///////////////////////////////////////////////

var langStart = {
	'langStartServer': "Start de Server"
};

///////////////////////////////////////////////
//
//   Language for wait.html
//
///////////////////////////////////////////////

var langWait = {
	'langPleaseWait20Seconds': "A.U.B Wacht 20 Seconden"
};

///////////////////////////////////////////////
//
//   Language for backup.html
//
///////////////////////////////////////////////

var langBackup = {
	'langStatus': "Aan het backuppen"
};

var jsBackup = {
	'Complete': "Backuppen Compleet! Server aan het Starten",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again"
};