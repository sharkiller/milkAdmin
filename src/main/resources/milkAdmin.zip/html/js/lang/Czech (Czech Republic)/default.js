/**
	milkAdmin - WebAdministrator of Minecraft Server for Bukkit
    Copyright (C) 2010-2011  Alejandro Barreiro (Sharkiller)
**/
/*	
    This file is part of milkAdmin.

    This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
	To view a copy of this license, visit http'://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to
	Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
*/

///////////////////////////////////////////////
//
//   Language for index.html
//
///////////////////////////////////////////////

var langIndex = {
	///////////////////
	//	Common
	///////////////////
	'lang1Yes': "Ano",
	'lang1No': "Ne",
	'lang1OK': "OK",
	'lang1Add': "Přidat",
	'lang1Cancel': "Zrušit",
	'lang1Send': "Poslat",
	'lang1Change': "Změnit",
	'lang1On': "Zap.",
	'lang1Off': "Vyp.",
	'lang1ReloadList': "Obnovit seznam",
	'lang1IPAddress': "IP Adresa",
	'lang1Player': "Hráč",
	'lang1Action': "Akce",
	'lang1User': "Uživatelské heslo",
	'lang1Password': "Heslo",
	///////////////////
	//	Header
	///////////////////
	'langAbout': "O programu…",
	'langLogout': "Odhlásit se",
	'langChooseLanguage': "Vybrat Jazyk:",
	'langTranslate': "Přelož do tvého jazyka",
	///////////////////
	//	Update Dialog
	///////////////////
	'langNewVersionAvailable': "Nová verze k dispozici ",
	'langVersionAvailable': "milkAdmin v_VER_ is available", // milkAdmin v1.0 is available
	'langUpdateNow': "Chcete nyní provést aktualizaci?",
	///////////////////
	//	About Dialog
	///////////////////
	'langmilkAdmin': "About milkAdmin",
	'langDesign': "Design a Programování",
	'langUpdates': "Aktualizace:",
	'langThanks': "Díky:",
	///////////////////
	//	Ban Dialog
	///////////////////
	'langBanOptions': "Možnosti banu",
	'langKickPlayer': "Vykopnutí hráče",
	'langBanPlayerName': "Ban Uživatelského jména",
	'langBanIPAddress': "Ban IP adresy ",
	'langCause': "Způsobit",
	///////////////////
	//	Main Menu
	///////////////////
	'langRestartServer': "Restart Serveru",
	'langReloadServer': "Obnovit server",
	'langBackupStart': "Začít zálohovat",
	'langSaveMap': "Uložení Světa",
	'langStopServer': "Zastavení serveru",
	///////////////////
	//	Sub Menu
	///////////////////
	'langServerSM': "Server",
	'langConsoleSM': "Konzole",
	'langPluginsSM': "Pluginy",
	'langBackupsSM': "Zálohovaní ",
	'langPlayersSM': "Hráči",
	'langBanListSM': "Banlist",
	'langWhitelistSM': "Bíla listina",
	///////////////////
	//	Server Info
	///////////////////
	'langLastRestart': "Poslední Restart",
	'langAmountPlayersOnline': "Počet online hráčů",
	'langFreeMemory': "Zbývá Paměti",
	'langUsedMemory': "Použité Paměti ",
	'langTotalMemory': "Celkem Paměti",
	'langMaxMemory': "Maximální Paměť",
	'langTitleMemory': "Memory Data - <b>Free Memory</b>: Show the amount of free memory in the Minecraft Server.<br><b>Used Memory</b>: Show the amount of used memory in the Minecraft Server.<br><b>Total Memory</b>: Show the total amount of memory that the Minecraft Server use right now.<br><b>Max Memory</b>: Show the maximum amount of memory that the Minecraft Server will attempt to use.",
	'langFreeSpace': "Volné místo",
	'langUsedSpace': "Použité místo",
	'langTotalSpace': "Celkové místo",
	'langTitleSpace': "Space Data - Based on &quot;Backup Folder&quot; directory.",
	'langServerVersion': "Verze Serveru",
	'langCraftbukkitBuild': "Build(verze) Craftbukkitu",
	///////////////////
	//	Server Panel
	///////////////////
	//	Server Info
	///////////////////
	'langServerInfoSM': "Informace o serveru",
	'langBroadcastMessage': "Broadcast Message",
	'langTitleBroadcastMessage': "Broadcast Message - Send a message to all players whitout tag.",
	'langLevelName': "Jméno hlavního levelu",
	'langTitleLevelName': "The value will be used as world name and as folder name.<br>You may also copy your saved game folder here, and change the name to the same as that folder\'s to load it instead. ",
	'langMCIPPORT': "IP a Port Minercaft Serveru",
	'langTitleMCIPPORT': "<b>IP:</b> Set this if you want the server to bind to a particular IP. It is strongly recommended that you leave server-ip blank!<br><b>Port:</b> Changes the port the server is hosting on. This port must be forwarded if the server is going through a router.<br><b>Valid values:</b><ul><li><b>IP:</b> Blank, or the IP you want your server to run on.</li><li><b>Port:</b> A number between <b>1-65535</b>. Default: <b>25565</b><ul><li>Should be greater than 20000 to avoid conflicts with system reserved ports.</li></ul></li></ul>",
	'langMaxPlayers': "Max Players",
	'langTitleMaxPlayers': "The max numbers of players that can play on the server at the same time.<br><i>Note that if more players are on the server it will use more resources.</i><br><i>Note also, admin connections are not counted against the max players.</i><br><b>Valid values:</b><ul><li>A number between <b>0-255</b>.</li></ul>",
	'langViewDistance': "Ukázat vzdálenost",
	'langTitleViewDistance': "The amount of chunks the server sends to the players.<br><b>Valid values:</b><ul><li>A number between <b>3-15</b>. Default: <b>10</b></li></ul>",
	'langHoldMessage': "Podržet zprávu",
	'langTitleHoldMessage': "Message that MCSODRTK will display when Server is on Hold.<br><i>Needs MinecraftRemoteToolkit</i>",
	'langAllowNether': "Povolit Nether",
	'langTitleAllowNether': "Allows players to travel to the Nether.<ul><li><b>true</b> = The server will allow Portals to send players to the Nether.</li><li><b>false</b> = Portals will not travel to the Nether.</li></ul>",
	'langSpawnMonsters': "Spawn Monster ",
	'langTitleSpawnMonsters': "Set true if you want monsters to be spawned at night, false if you don\'t.<br><i>Tip: if you have major lag, turn this off.</i><ul><li><b>true</b> = Monsters will appear at night and in the dark.</li><li><b>false</b> = No monsters.</li></ul>",
	'langSpawnAnimals': "Spawn Zvířat",
	'langTitleSpawnAnimals': "Animals will be able to spawn.<ul><li><b>true</b> = Animals spawn as normal.</li><li><b>false</b> = Animals will immediately vanish.</li></ul>",
	'langOnlineMode': "Online Režim (Ověření Jména)",
	'langTitleOnlineMode': "Server checks connecting players against minecraft\'s account database.<br>Only set this to false if your server is not connected to the Internet.<ul><li><b>true</b> = The server will assume it has an Internet connection and check in minecraft.net every connecting player.</li><li><b>false</b> = The server will not attempt to check connecting players.</li></ul>",
	'langPVP': "Hráč proti Hráči (HPH-PVP)",
	'langTitlePVP': "Enable Player vs Player on the server.<br><i>Note: Hitting a player while having PvP set to false and having tamed wolfs will still cause the wolfs<br>attacking the attacked player.</i><ul><li><b>true</b> = Players will be able to kill each other.</li><li><b>false</b> = Players cannot kill other players.</li></ul>",
	'langAllowFlight': "Povolit Létání ",
	'langTitleAllowFlight': "Will allow users to use flight/no-clip on your server, if they have an mod that provides flight/no-clip installed.<ul><li><b>true</b> = Flight/no clip is allowed, and used if the player have a no-clip mod installed.</li><li><b>false</b> = Flight/no-clip is not allowed.</li></ul>",
	'langWhitelist': "Bíla listina",
	'langTitleWhitelist': "Enable a white list on the server. With a white list enabled, users not on the white list will be unable to connect.<ul><li><b>true</b> = The file white-list.txt is used to generate the white list.</li><li><b>false</b> = No white list is used.</li></ul>",
	///////////////////
	//	Whitelist
	///////////////////
	'langWhitelistSM': "Bíla listina",
	'langWLAddPlayer': "Přidat hráče",
	'langWLDeleteSelected': "Smazat označené",
	'langWLSaveChanges': "Uložit změny",
	///////////////////
	//	Plugin Panel
	///////////////////
	'langEnablePlugin': "Plugin Umožněn",
	'langEnable': "Umožnit",
	'langPluginName': "Jméno Pluginu",
	'langVersion': "Verze",
	'langReloadTheList': "Znovu načtení seznamu",
	///////////////////
	//	Backup Panel
	///////////////////
	'langChooseYourBackup': "Vyberte si zálohu",
	'langRestoreBackup': "Obnovení zálohy",
	'langDeleteBackup': "Odstranění zálohy",
	'langBackupClear': "Oddělat předchozí složku před provedením zálohy",
	///////////////////
	//	Players
	///////////////////
	'langUserManagement': "Správa Uživatelů ",
	'langIP': "IP",
	'langPort': "Port",
	'langKill': "Zabít ",
	'langKick': "(vy)Kopnout",
	'langBanName': "BAN",
	'langBanIP': "BAN IP Adresy",
	'langAmount': "Množství Času",
	'langShootArrow': "Vystřelit Šíp",
	'langShootFireball': "Střelit Ohnivou kouli",
	'langThrowEgg': "Hodit Vejce ",
	'langThrowSnowball': "Hodit Sněhovou Kouli ",
	'langTeleportToPlayer': "Teleport za hráčem",
	'langTeleportToCoord': "Teleport na Souřadnice",
	'langChangeName': "Změna Jména",
	///////////////////
	//	Ban List
	///////////////////
	'langCreateBan': "Ban na IP Adresu nebo na Jméno",
	'langClearFilter': "Vymazat Filtr",
	///////////////////
	//	milkAdmin
	///////////////////
	'langRegisterAdmin': "Registrace Nového Admina",
	'langCreateAdmin': "Vytvoření Admina"
};

var jsIndex = {
	'sProcessing': "Zpracovávám  ",
	'sLengthMenu': "Ukázat _MENU_ pluginy", // Show 10 plugins
	'sZeroRecords': "Plugin nebyl nalezen",
	'sInfo': "Zobrazeny _START_->_END_ of _TOTAL_ pluginy", // Showing 1->10 of 17 plugins
	'sInfoEmpty': "Pluginy nebyly zobrazeny",
	'sInfoFiltered': "(Filtr z _MAX_ pluginu)", // (filter of 17 plugins)
	'sSearch': "Hledání Pluginu:",
	'sFirst': "První",
	'sPrevious': "Předešlá",
	'sNext': "Další",
	'sLast': "Poslední",
	'ReloadServer': "Obnovovaní Serveru!",
	'RestartServer': "Restartovaní Serveru!",
	'StopServer': "Zastavovaní serveru!",
	'EnablePlugin': "Plugin Povolen!",
	'StartBackup': "Začíná záloha!",
	'RTKNeeded': "You need the RemoteToolkit to use this function!",
	'NoUsersOnline': "Žádní hráči online",
	'NoBackups': "Nejsou tu zálohy!",
	'activate': "Aktivace ",
	'deactivate': "Deaktivace",
	'unban': "Zrušení BANu",
	'MustLogin': "You must login!",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'InvalidIP': "Špatná IP Adresa",
	'UpdateNow': "Aktualizovat Teď ",
	'later': "Později"
};

var jsAjax = {
	'accountcreated': "Účet vytvořen ",
	'worldsaved': "Svět Uložen!",
	'messagesent': "Zpráva Poslána ",
	'broadcastedmessage': "Vyslaná Zpráva",
	'forcestop': "Stopnutá Platnost",
	'plugindisabled': "_NAME_\'s si zakázal plugin", // PluginX's plugin disabled.
	'pluginenabled': "_NAME_\'s si povolil plugin", // PluginX's plugin enabled.
	'editedproperty': "Upraven majetek",
	'worldbackedup': "Záloha byla nahozena na Svět",
	'deletebackup': "Záloha odstraněná ",
	'kickplayer': "_NAME_ byl vykopnut s toho dle serveru", // Sharkiller kicked from the server
	'itemsgiven': "_NAME_ dostal _AMOUNT_ jednotek _ITEM_", // Sharkiller was given 64 units of IRON
	'itemsremoved': "_NAME_ bylo odstraněno _AMOUNT_ jednotek _ITEM_", // Sharkiller removed 64 units of TNT
	'playerkilled': "_NAME_ byl zabit", // Sharkiller killed
	'healthchanged': "_NAME_\'s si změnil životy na _AMOUNT_/20", // Sharkiller's health changed to 5/20
	'playerbanned': "_NAME_ je zaBANovaná!", // Sharkiller was banned!
	'playerunbanned': "_NAME_ je odBANovaná!", // Sharkiller was unbanned!
	'ipbanned': "_IP_ je zaBANovaná!", // 19.64.84.24 was banned!
	'ipunbanned': "_IP_ je odBANovaná!", // 19.64.84.24 was unbanned!
	'arrowshooted': "Arrow Shot!", 
	'fireballshooted': "Ohnivá koule vystřelena!", 
	'throwsnowball': "Sněhová koule byla hozena!",
	'throwegg': "Egg thrown!",
	'changename': "_OLD_\'s jméno změněno na _NEW_", // Sharkiller's name changed to Peter
	'playerteleported': "Hráč byl Teleportován",
	'langchanged': "Jazyk Změněn! Načítaní stránky...",
	'wlloaded': "Whitelist loaded!",
	'wladded': "Added to Whitelist!",
	'wlsaved': "Whitelist has been saved successfully!",
	///////////////////
	//	Errors
	///////////////////
	'badparameters': "Špatné Parametry",
	'messageempty': "Prázdna Zpráva",
	'wladdfail': "Failed to add player to Whitelist!",
	'wlsavefail': "Failed to save Whitelist! Try again!",
	'playernotconnected': "Hráč není připojen",
	'playernotbanned': "Hráč není zabanovaný",
	'ipnotbanned': "Ip adresa není zaBANovaná",
	'langnotfound': "Jazyk nebyl nalezen!"
};

///////////////////////////////////////////////
//
//   Language for login.html
//
///////////////////////////////////////////////

var langLogin = {
	'langmilkAdminLogin': "Přihlásit se na milkAdmin",
	'langUsername': "Uživatelské Jméno",
	'langPassword': "Heslo",
	'langLogin': "Přihlášení "
};

var jsLogin = {
	'welcome': "Welcome! Loading page...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'invalidlogin': "Špatné Uživatelské Jméno nebo Heslo"
};

///////////////////////////////////////////////
//
//   Language for register.html
//
///////////////////////////////////////////////

var langRegister = {
	'langCreateAnAccount': "Vytvořit si Účet",
	'langUsername': "Uživatelské Jméno",
	'langPassword': "Heslo",
	'langCreateAccount': "Vytvořit Účet "
};

var jsRegister = {
	'created': "Účet Vytvořen! Načítám stránku...",
	'notadmin': "Nemůžete použít \"admin\", jako uživatelské jméno",
	'baduser': "Zadejte prosím platné uživatelské jméno a heslo",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'error': "Neplatné uživatelské jméno a heslo!"
};

///////////////////////////////////////////////
//
//   Language for startServer.html
//
///////////////////////////////////////////////

var langStart = {
	'langStartServer': "Start Serveru"
};

///////////////////////////////////////////////
//
//   Language for wait.html
//
///////////////////////////////////////////////

var langWait = {
	'langPleaseWait20Seconds': "Počkejte Prosím 20 Vteřin"
};

///////////////////////////////////////////////
//
//   Language for backup.html
//
///////////////////////////////////////////////

var langBackup = {
	'langStatus': "Zálohování"
};

var jsBackup = {
	'Complete': "Zálohování dokončeno! Startuji Server...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again"
};