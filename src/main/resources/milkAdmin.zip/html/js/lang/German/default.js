/**
	milkAdmin - WebAdministrator of Minecraft Server for Bukkit
    Copyright (C) 2010-2011  Alejandro Barreiro (Sharkiller)
**/
/*	
    This file is part of milkAdmin.

    This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
	To view a copy of this license, visit http'://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to
	Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
*/

///////////////////////////////////////////////
//
//   Language for index.html
//
///////////////////////////////////////////////

var langIndex = {
	///////////////////
	//	Common
	///////////////////
	'lang1Yes': "Ja",
	'lang1No': "Nein",
	'lang1OK': "OK",
	'lang1Add': "Add",
	'lang1Cancel': "Abbrechen",
	'lang1Send': "Senden",
	'lang1Change': "Ändern",
	'lang1On': "An",
	'lang1Off': "Aus",
	'lang1ReloadList': "Liste aktualisieren",
	'lang1IPAddress': "IP Addresse",
	'lang1Player': "Spieler",
	'lang1Action': "Aktion",
	'lang1User': "Benutzername",
	'lang1Password': "Passwort",
	///////////////////
	//	Header
	///////////////////
	'langAbout': "Über...",
	'langLogout': "Ausloggen",
	'langChooseLanguage': "Wähl eine Sprache",
	'langTranslate': "Übersetze in ihre Sprache",
	///////////////////
	//	Update Dialog
	///////////////////
	'langNewVersionAvailable': "Neue Version verfügbar",
	'langVersionAvailable': "milkAdmin v_VER_ is available", // milkAdmin v1.0 is available
	'langUpdateNow': "Möchtest du jetzt updaten?",
	///////////////////
	//	About Dialog
	///////////////////
	'langmilkAdmin': "Über milkAdmin",
	'langDesign': "Design und Programmierung",
	'langUpdates': "Updates:",
	'langThanks': "Danke an:",
	///////////////////
	//	Ban Dialog
	///////////////////
	'langBanOptions': "Ban Optionen",
	'langKickPlayer': "Spieler kicken",
	'langBanPlayerName': "Ban Spieler Name",
	'langBanIPAddress': "Ban IP Addresse",
	'langCause': "Ursache",
	///////////////////
	//	Main Menu
	///////////////////
	'langRestartServer': "Server neustarten",
	'langReloadServer': "Server neu laden",
	'langBackupStart': "Starte Backup",
	'langSaveMap': "Welt speichern",
	'langStopServer': "Server Stoppen",
	///////////////////
	//	Sub Menu
	///////////////////
	'langServerSM': "Server",
	'langConsoleSM': "Konsole",
	'langPluginsSM': "Plugins",
	'langBackupsSM': "Backups",
	'langPlayersSM': "Spieler",
	'langBanListSM': "Banlist",
	'langWhitelistSM': "Whitelist",
	///////////////////
	//	Server Info
	///////////////////
	'langLastRestart': "Letzter Neustart",
	'langAmountPlayersOnline': "Number of Players Online",
	'langFreeMemory': "Freier Arbeitsspeicher",
	'langUsedMemory': "Belegter Arbeitsspeicher",
	'langTotalMemory': "Gesamter Arbeitsspeicher",
	'langMaxMemory': "Maximaler Arbeitsspeicher",
	'langTitleMemory': "Arbeitsspeicher -<b> Freier Arbeitsspeicher</b>: Beachtet denn freien Speicher auf dem Minecraft Server.<br><b>Verwendeter Speicher</b>: Beachtet den genutzen Arbeitsspeicher auf dem Minecraft Server.<br><b>Insgesamter Speicher</b>:Insgesamter Speicher der dem Minecraft Server zur verfügung steht.<br><b>Maximaler Speicher</b>:Zeigt den Speicher an, den der Minecraft Server maximal nutzten wird.",
	'langFreeSpace': "Freier Speicher",
	'langUsedSpace': "Benutzter Speicher",
	'langTotalSpace': "Speicher Insgesammt",
	'langTitleSpace': "Space Data - Based on &quot;Backup Folder&quot; directory.",
	'langServerVersion': "Server Version",
	'langCraftbukkitBuild': "Craftbukkit Build",
	///////////////////
	//	Server Panel
	///////////////////
	//	Server Info
	///////////////////
	'langServerInfoSM': "Server Info",
	'langBroadcastMessage': "Broadcast Nachricht",
	'langTitleBroadcastMessage': "Broadcast Nachricht - Sendet eine Nachricht an alle Spieler ohne Tags",
	'langLevelName': "Hauptlevel Name",
	'langTitleLevelName': "The value will be used as world name and as folder name.<br>You may also copy your saved game folder here, and change the name to the same as that folder\'s to load it instead. ",
	'langMCIPPORT': "Minecraft Server IP und Port",
	'langTitleMCIPPORT': "<b>IP:</b> Set this if you want the server to bind to a particular IP. It is strongly recommended that you leave server-ip blank!<br><b>Port:</b> Changes the port the server is hosting on. This port must be forwarded if the server is going through a router.<br><b>Valid values:</b><ul><li><b>IP:</b> Blank, or the IP you want your server to run on.</li><li><b>Port:</b> A number between <b>1-65535</b>. Default: <b>25565</b><ul><li>Should be greater than 20000 to avoid conflicts with system reserved ports.</li></ul></li></ul>",
	'langMaxPlayers': "Maximale Spieler",
	'langTitleMaxPlayers': "The max numbers of players that can play on the server at the same time.<br><i>Note that if more players are on the server it will use more resources.</i><br><i>Note also, admin connections are not counted against the max players.</i><br><b>Valid values:</b><ul><li>A number between <b>0-255</b>.</li></ul>",
	'langViewDistance': "View Distance",
	'langTitleViewDistance': "The amount of chunks the server sends to the players.<br><b>Valid values:</b><ul><li>A number between <b>3-15</b>. Default: <b>10</b></li></ul>",
	'langHoldMessage': "Hold Message",
	'langTitleHoldMessage': "Message that MCSODRTK will display when Server is on Hold.<br><i>Needs MinecraftRemoteToolkit</i>",
	'langAllowNether': "Nether Erlauben",
	'langTitleAllowNether': "Allows players to travel to the Nether.<ul><li><b>true</b> = The server will allow Portals to send players to the Nether.</li><li><b>false</b> = Portals will not travel to the Nether.</li></ul>",
	'langSpawnMonsters': "Monster spawnen",
	'langTitleSpawnMonsters': "Set true if you want monsters to be spawned at night, false if you don\'t.<br><i>Tip: if you have major lag, turn this off.</i><ul><li><b>true</b> = Monsters will appear at night and in the dark.</li><li><b>false</b> = No monsters.</li></ul>",
	'langSpawnAnimals': "Tiere spawnen",
	'langTitleSpawnAnimals': "Animals will be able to spawn.<ul><li><b>true</b> = Animals spawn as normal.</li><li><b>false</b> = Animals will immediately vanish.</li></ul>",
	'langOnlineMode': "Online Modus (Namen verifizieren)",
	'langTitleOnlineMode': "Server checks connecting players against minecraft\'s account database.<br>Only set this to false if your server is not connected to the Internet.<ul><li><b>true</b> = The server will assume it has an Internet connection and check in minecraft.net every connecting player.</li><li><b>false</b> = The server will not attempt to check connecting players.</li></ul>",
	'langPVP': "Spieler gegen Spieler (PVP)",
	'langTitlePVP': "Enable Player vs Player on the server.<br><i>Note: Hitting a player while having PvP set to false and having tamed wolfs will still cause the wolfs<br>attacking the attacked player.</i><ul><li><b>true</b> = Players will be able to kill each other.</li><li><b>false</b> = Players cannot kill other players.</li></ul>",
	'langAllowFlight': "Fliegen erlauben",
	'langTitleAllowFlight': "Will allow users to use flight/no-clip on your server, if they have an mod that provides flight/no-clip installed.<ul><li><b>true</b> = Flight/no clip is allowed, and used if the player have a no-clip mod installed.</li><li><b>false</b> = Flight/no-clip is not allowed.</li></ul>",
	'langWhitelist': "Whitelist",
	'langTitleWhitelist': "Enable a white list on the server. With a white list enabled, users not on the white list will be unable to connect.<ul><li><b>true</b> = The file white-list.txt is used to generate the white list.</li><li><b>false</b> = No white list is used.</li></ul>",
	///////////////////
	//	Whitelist
	///////////////////
	'langWhitelistSM': "Whitelist",
	'langWLAddPlayer': "Spieler Hinzufügen",
	'langWLDeleteSelected': "Auswahl Löschen",
	'langWLSaveChanges': "Änderungen gespeichert",
	///////////////////
	//	Plugin Panel
	///////////////////
	'langEnablePlugin': "Plugin aktivieren",
	'langEnable': "Aktivieren",
	'langPluginName': "Plugin Name",
	'langVersion': "Version",
	'langReloadTheList': "Liste aktualisieren",
	///////////////////
	//	Backup Panel
	///////////////////
	'langChooseYourBackup': "Wähle deine Sicherung",
	'langRestoreBackup': "Backup wiederherstellen",
	'langDeleteBackup': "Sicherung Löschen",
	'langBackupClear': "Entfernen Sie den vorherigen Ordnern vor dem Wiederherstellen der Sicherung",
	///////////////////
	//	Players
	///////////////////
	'langUserManagement': "Spieler Verwaltung",
	'langIP': "IP",
	'langPort': "Port",
	'langKill': "Kill",
	'langKick': "Kick",
	'langBanName': "Ban",
	'langBanIP': "Ban IP",
	'langAmount': "Anzahl",
	'langShootArrow': "Pfeil Schießen",
	'langShootFireball': "Feuerball schießen",
	'langThrowEgg': "Eier werfen",
	'langThrowSnowball': "Schneeball werfen",
	'langTeleportToPlayer': "Zum Spieler Teleportieren",
	'langTeleportToCoord': "Zur Koordinate Teleportieren",
	'langChangeName': "Namen wechseln",
	///////////////////
	//	Ban List
	///////////////////
	'langCreateBan': "IP-Adresse oder Name Bannen",
	'langClearFilter': "Filter löschen",
	///////////////////
	//	milkAdmin
	///////////////////
	'langRegisterAdmin': "Neuen Admin Registrieren",
	'langCreateAdmin': "Admin erstellen"
};

var jsIndex = {
	'sProcessing': "Verarbeite...",
	'sLengthMenu': "Zeige _MENU_ plugins", // Show 10 plugins
	'sZeroRecords': "Keine Plugins gefunden.",
	'sInfo': "Zeige _START_ bis _END_ von _TOTAL_ plugins", // Showing 1->10 of 17 plugins
	'sInfoEmpty': "Keine Plugins zum anzeigen",
	'sInfoFiltered': "(Filter von _MAX_ Plugins)", // (filter of 17 plugins)
	'sSearch': "Plugin Suchen:",
	'sFirst': "Zuerst",
	'sPrevious': "Letzte",
	'sNext': "Nächste",
	'sLast': "Letzte",
	'ReloadServer': "Server wird neu geladen!",
	'RestartServer': "Server wird neu gestartet!",
	'StopServer': "Server wird gestoppt",
	'EnablePlugin': "Plugin angeschaltet!",
	'StartBackup': "Starte Backup!",
	'RTKNeeded': "You need the RemoteToolkit to use this function!",
	'NoUsersOnline': "Keine Spieler online",
	'NoBackups': "Keine Backups vorhanden!",
	'activate': "Aktivieren",
	'deactivate': "Deaktivieren",
	'unban': "Entbannen",
	'MustLogin': "You must login!",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'InvalidIP': "Ungültige IP Adresse",
	'UpdateNow': "Jetzt Updaten",
	'later': "Später"
};

var jsAjax = {
	'accountcreated': "Account erstellt!",
	'worldsaved': "Welt gespeichert!",
	'messagesent': "Nachricht gesendet",
	'broadcastedmessage': "Gesendete Nachricht",
	'forcestop': "Stop erzwingen",
	'plugindisabled': "_NAME_\'s Plugin deaktiviert", // PluginX's plugin disabled.
	'pluginenabled': "NAME_\'s plugin aktiviert!", // PluginX's plugin enabled.
	'editedproperty': "Eigenschaft verändert",
	'worldbackedup': "Welt wurde gesichert",
	'deletebackup': "Sicherung gelöscht",
	'kickplayer': "_NAME_ wurde vom Server gekickt", // Sharkiller kicked from the server
	'itemsgiven': "_NAME_ wurden _AMOUNT_ von _ITEM_ gegeben", // Sharkiller was given 64 units of IRON
	'itemsremoved': "_NAME_ wurden _AMOUNT_ von _ITEM_ genommen", // Sharkiller removed 64 units of TNT
	'playerkilled': "_NAME_ wurde getötet", // Sharkiller killed
	'healthchanged': "_NAME_\'s gesundheit wurde auf _AMOUNT_/20 geändert", // Sharkiller's health changed to 5/20
	'playerbanned': "_NAME_ wurde gebannt", // Sharkiller was banned!
	'playerunbanned': "_NAME_ wurde entbannt", // Sharkiller was unbanned!
	'ipbanned': "_IP_ wurde gebannt", // 19.64.84.24 was banned!
	'ipunbanned': "_IP_ wurde entbannt", // 19.64.84.24 was unbanned!
	'arrowshooted': "Arrow Shot!", 
	'fireballshooted': "Feuerball geschossen!", 
	'throwsnowball': "Schneeball geworfen!",
	'throwegg': "Egg thrown!",
	'changename': "_OLD_\'s Name wurde geändert zu _NEW_", // Sharkiller's name changed to Peter
	'playerteleported': "Spieler wurde Teleportiert",
	'langchanged': "Sprache gewechselt! Seite wird neu geladen...",
	'wlloaded': "Whitelist loaded!",
	'wladded': "Zur Whitelist hinzugefügt!",
	'wlsaved': "Whitelist wurde erfolgreich gespeichert!",
	///////////////////
	//	Errors
	///////////////////
	'badparameters': "Ungültige Parameter",
	'messageempty': "Leere Nachricht",
	'wladdfail': "Failed to add player to Whitelist!",
	'wlsavefail': "Failed to save Whitelist! Try again!",
	'playernotconnected': "Spieler nicht verbunden",
	'playernotbanned': "Spieler nicht gebannt",
	'ipnotbanned': "IP nicht gebannt",
	'langnotfound': "Sprache nicht gefunden!"
};

///////////////////////////////////////////////
//
//   Language for login.html
//
///////////////////////////////////////////////

var langLogin = {
	'langmilkAdminLogin': "Einloggen in milkAdmin",
	'langUsername': "Benutzername",
	'langPassword': "Passwort",
	'langLogin': "Login"
};

var jsLogin = {
	'welcome': "Willkommen! Lade Seite...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'invalidlogin': "Falscher Name und Passwort!"
};

///////////////////////////////////////////////
//
//   Language for register.html
//
///////////////////////////////////////////////

var langRegister = {
	'langCreateAnAccount': "Erstelle einen Account",
	'langUsername': "Benutzername",
	'langPassword': "Passwort",
	'langCreateAccount': "Account erstellen"
};

var jsRegister = {
	'created': "Account erstellt! Lade Seite...",
	'notadmin': "Du kannst nicht \"admin\" als Benutzername wählen",
	'baduser': "Bitte gebe einen gültigen Benutzernamen und Passwort an",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'error': "Falscher Name und Passwort!"
};

///////////////////////////////////////////////
//
//   Language for startServer.html
//
///////////////////////////////////////////////

var langStart = {
	'langStartServer': "Starte Server"
};

///////////////////////////////////////////////
//
//   Language for wait.html
//
///////////////////////////////////////////////

var langWait = {
	'langPleaseWait20Seconds': "Bitte warte 20 Sekunden"
};

///////////////////////////////////////////////
//
//   Language for backup.html
//
///////////////////////////////////////////////

var langBackup = {
	'langStatus': "Backup gestartet"
};

var jsBackup = {
	'Complete': "Backup Fertiggestellt! Starte Server...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again"
};