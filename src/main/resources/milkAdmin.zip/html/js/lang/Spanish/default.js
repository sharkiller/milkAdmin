/**
	milkAdmin - WebAdministrator of Minecraft Server for Bukkit
    Copyright (C) 2010-2011  Alejandro Barreiro (Sharkiller)
**/
/*	
    This file is part of milkAdmin.

    This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
	To view a copy of this license, visit http'://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to
	Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
*/

///////////////////////////////////////////////
//
//   Language for index.html
//
///////////////////////////////////////////////

var langIndex = {
	///////////////////
	//	Common
	///////////////////
	'lang1Yes': "Si",
	'lang1No': "No",
	'lang1OK': "Aceptar",
	'lang1Add': "Add",
	'lang1Cancel': "Cancelar",
	'lang1Send': "Enviar",
	'lang1Change': "Cambiar",
	'lang1On': "Encendido",
	'lang1Off': "Apagado",
	'lang1ReloadList': "Recargar Lista",
	'lang1IPAddress': "Direccion IP",
	'lang1Player': "Jugador",
	'lang1Action': "Accion",
	'lang1User': "Usuario",
	'lang1Password': "Contraseña",
	///////////////////
	//	Header
	///////////////////
	'langAbout': "Sobre...",
	'langLogout': "Salir",
	'langChooseLanguage': "Elige un idioma:",
	'langTranslate': "Traducir a tu idioma",
	///////////////////
	//	Update Dialog
	///////////////////
	'langNewVersionAvailable': "Nueva Version Disponible",
	'langVersionAvailable': "milkAdmin v_VER_ is available", // milkAdmin v1.0 is available
	'langUpdateNow': "Quieres actualizarlo ahora?",
	///////////////////
	//	About Dialog
	///////////////////
	'langmilkAdmin': "Acerca de milkAdmin",
	'langDesign': "Diseño y programacion:",
	'langUpdates': "Actualizaciones:",
	'langThanks': "Gracias a:",
	///////////////////
	//	Ban Dialog
	///////////////////
	'langBanOptions': "Opciones de Baneo",
	'langKickPlayer': "Patear Jugador",
	'langBanPlayerName': "Banear el Nombre del Jugador",
	'langBanIPAddress': "Banear Direccion IP",
	'langCause': "Causa",
	///////////////////
	//	Main Menu
	///////////////////
	'langRestartServer': "Reiniciar Servidor",
	'langReloadServer': "Recargar Servidor",
	'langBackupStart': "Iniciar respaldo",
	'langSaveMap': "Guardar Mundo",
	'langStopServer': "Detener Servidor",
	///////////////////
	//	Sub Menu
	///////////////////
	'langServerSM': "Servidor",
	'langConsoleSM': "Consola",
	'langPluginsSM': "Plugins",
	'langBackupsSM': "Respaldos",
	'langPlayersSM': "Jugadores",
	'langBanListSM': "Banlist",
	'langWhitelistSM': "Lista de espera.",
	///////////////////
	//	Server Info
	///////////////////
	'langLastRestart': "Ultimo Reinicio",
	'langAmountPlayersOnline': "Number of Players Online",
	'langFreeMemory': "Memoria Libre",
	'langUsedMemory': "Memoria Usada",
	'langTotalMemory': "Memoria Total",
	'langMaxMemory': "Maxima Memoria",
	'langTitleMemory': "Informacion de la memoria - <b>Memoria disponible</b>: Mostrar la cantidad de memoria disponible en el servidor.<br><b>Memoria en Uso</b>: Mostrar la cantidad de memoria usada en el servidor.<br><b>Memoria Total</b>: Mostrar la cantidad total de memoria que el servidor esta usando.<br><b>Memoria Total</b>: Mostrar la cantidad total de memoria que el servidor intentara usar.",
	'langFreeSpace': "Espacio disponible",
	'langUsedSpace': "Espacio Usado",
	'langTotalSpace': "Espacio total",
	'langTitleSpace': "Informacion del espacio - Basado en &quot;Carpeta de respaldo&quot; direccion.",
	'langServerVersion': "Version del Servidor",
	'langCraftbukkitBuild': "Craftbukkit build",
	///////////////////
	//	Server Panel
	///////////////////
	//	Server Info
	///////////////////
	'langServerInfoSM': "Informacion del servidor",
	'langBroadcastMessage': "Mensaje global",
	'langTitleBroadcastMessage': "Mensaje global - Envia un mensaje a todos los jugadores sin etiqueta",
	'langLevelName': "Nombre del nivel principal",
	'langTitleLevelName': "The value will be used as world name and as folder name.<br>You may also copy your saved game folder here, and change the name to the same as that folder\'s to load it instead. ",
	'langMCIPPORT': "Minecraft Server IP and Port",
	'langTitleMCIPPORT': "<b>IP:</b> Set this if you want the server to bind to a particular IP. It is strongly recommended that you leave server-ip blank!<br><b>Port:</b> Changes the port the server is hosting on. This port must be forwarded if the server is going through a router.<br><b>Valid values:</b><ul><li><b>IP:</b> Blank, or the IP you want your server to run on.</li><li><b>Port:</b> A number between <b>1-65535</b>. Default: <b>25565</b><ul><li>Should be greater than 20000 to avoid conflicts with system reserved ports.</li></ul></li></ul>",
	'langMaxPlayers': "Max Players",
	'langTitleMaxPlayers': "The max numbers of players that can play on the server at the same time.<br><i>Note that if more players are on the server it will use more resources.</i><br><i>Note also, admin connections are not counted against the max players.</i><br><b>Valid values:</b><ul><li>A number between <b>0-255</b>.</li></ul>",
	'langViewDistance': "View Distance",
	'langTitleViewDistance': "The amount of chunks the server sends to the players.<br><b>Valid values:</b><ul><li>A number between <b>3-15</b>. Default: <b>10</b></li></ul>",
	'langHoldMessage': "Hold Message",
	'langTitleHoldMessage': "Message that MCSODRTK will display when Server is on Hold.<br><i>Needs MinecraftRemoteToolkit</i>",
	'langAllowNether': "Allow Nether",
	'langTitleAllowNether': "Allows players to travel to the Nether.<ul><li><b>true</b> = The server will allow Portals to send players to the Nether.</li><li><b>false</b> = Portals will not travel to the Nether.</li></ul>",
	'langSpawnMonsters': "Aparecer Monstruos",
	'langTitleSpawnMonsters': "Set true if you want monsters to be spawned at night, false if you don\'t.<br><i>Tip: if you have major lag, turn this off.</i><ul><li><b>true</b> = Monsters will appear at night and in the dark.</li><li><b>false</b> = No monsters.</li></ul>",
	'langSpawnAnimals': "Aparecer Animales",
	'langTitleSpawnAnimals': "Animals will be able to spawn.<ul><li><b>true</b> = Animals spawn as normal.</li><li><b>false</b> = Animals will immediately vanish.</li></ul>",
	'langOnlineMode': "Modo En Línea (Verificar Nombres)",
	'langTitleOnlineMode': "Server checks connecting players against minecraft\'s account database.<br>Only set this to false if your server is not connected to the Internet.<ul><li><b>true</b> = The server will assume it has an Internet connection and check in minecraft.net every connecting player.</li><li><b>false</b> = The server will not attempt to check connecting players.</li></ul>",
	'langPVP': "Jugador vs Jugador (PVP)",
	'langTitlePVP': "Enable Player vs Player on the server.<br><i>Note: Hitting a player while having PvP set to false and having tamed wolfs will still cause the wolfs<br>attacking the attacked player.</i><ul><li><b>true</b> = Players will be able to kill each other.</li><li><b>false</b> = Players cannot kill other players.</li></ul>",
	'langAllowFlight': "Permitir Volar",
	'langTitleAllowFlight': "Will allow users to use flight/no-clip on your server, if they have an mod that provides flight/no-clip installed.<ul><li><b>true</b> = Flight/no clip is allowed, and used if the player have a no-clip mod installed.</li><li><b>false</b> = Flight/no-clip is not allowed.</li></ul>",
	'langWhitelist': "Whitelist",
	'langTitleWhitelist': "Enable a white list on the server. With a white list enabled, users not on the white list will be unable to connect.<ul><li><b>true</b> = The file white-list.txt is used to generate the white list.</li><li><b>false</b> = No white list is used.</li></ul>",
	///////////////////
	//	Whitelist
	///////////////////
	'langWhitelistSM': "Lista de espera.",
	'langWLAddPlayer': "Add player",
	'langWLDeleteSelected': "Delete Selected",
	'langWLSaveChanges': "Save Changes",
	///////////////////
	//	Plugin Panel
	///////////////////
	'langEnablePlugin': "Permitir Plug-in",
	'langEnable': "Activar",
	'langPluginName': "Nombre del Plug-in",
	'langVersion': "Version",
	'langReloadTheList': "Recargar la lista",
	///////////////////
	//	Backup Panel
	///////////////////
	'langChooseYourBackup': "Elige tu Copia de Seguridad",
	'langRestoreBackup': "Restaurar Copia de Seguridad",
	'langDeleteBackup': "Borrar Copia de Seguridad",
	'langBackupClear': "Remove previous folders before restoring the backup",
	///////////////////
	//	Players
	///////////////////
	'langUserManagement': "Gestor de Usuarios",
	'langIP': "Direccion IP",
	'langPort': "Puerto",
	'langKill': "Asesinar",
	'langKick': "Echar",
	'langBanName': "Banear",
	'langBanIP': "Banear IP",
	'langAmount': "Cantidad de veces",
	'langShootArrow': "Disparar Flecha",
	'langShootFireball': "Disparar bola de fuego",
	'langThrowEgg': "Tirar Huevo",
	'langThrowSnowball': "Tirar Bola de Nieve",
	'langTeleportToPlayer': "Transportarte a un Jugador",
	'langTeleportToCoord': "Transportar a coordenadas",
	'langChangeName': "Cambiar nombre",
	///////////////////
	//	Ban List
	///////////////////
	'langCreateBan': "Banear direccion IP o Nombre",
	'langClearFilter': "Eliminar Filtro",
	///////////////////
	//	milkAdmin
	///////////////////
	'langRegisterAdmin': "Registrar a un nuevo administrador",
	'langCreateAdmin': "Crear administrador"
};

var jsIndex = {
	'sProcessing': "Procesando...",
	'sLengthMenu': "Mostrar_menu_plugins", // Show 10 plugins
	'sZeroRecords': "No se encontraron Plug-ins",
	'sInfo': "Mostrando_INICIO_->_FINAL_de_TOTAL_plugins", // Showing 1->10 of 17 plugins
	'sInfoEmpty': "No hay plug-ins para mostrar",
	'sInfoFiltered': "(filtro de_MAXIMOS_plugins)", // (filter of 17 plugins)
	'sSearch': "Buscar plug-in",
	'sFirst': "Primero",
	'sPrevious': "Previo",
	'sNext': "Siguiente",
	'sLast': "Ultimo",
	'ReloadServer': "Recargando Servidor!",
	'RestartServer': "Reiniciando Servidor!",
	'StopServer': "Parando Servidor!",
	'EnablePlugin': "Plug-in Habilitado!",
	'StartBackup': "Empezando el respaldo!",
	'RTKNeeded': "You need the RemoteToolkit to use this function!",
	'NoUsersOnline': "No hay jugadores En Linea",
	'NoBackups': "No hay respaldos!",
	'activate': "Activar",
	'deactivate': "Desactivar",
	'unban': "Desbanear",
	'MustLogin': "You must login!",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'InvalidIP': "Direccion IP Invalida",
	'UpdateNow': "Actualizar ahora",
	'later': "Despues"
};

var jsAjax = {
	'accountcreated': "Cuenta Creada!",
	'worldsaved': "Mundo Guardado!",
	'messagesent': "Mensaje Enviado",
	'broadcastedmessage': "Emitir Mensaje",
	'forcestop': "Forzar a que se Detenga",
	'plugindisabled': "_NOMBRE_del plugin desactivado", // PluginX's plugin disabled.
	'pluginenabled': "_NOMBRE_del plugin habilitado", // PluginX's plugin enabled.
	'editedproperty': "Propiedad editada",
	'worldbackedup': "Mundo respaldado",
	'deletebackup': "Respaldo borrado",
	'kickplayer': "_NAME_ expulsado del servidor", // Sharkiller kicked from the server
	'itemsgiven': "_NAME_le fueron dados_AMOUNT_ unidades de _ITEM_", // Sharkiller was given 64 units of IRON
	'itemsremoved': "_NAME_ le han sido quitadas _AMOUNT_ unidades de _ITEM", // Sharkiller removed 64 units of TNT
	'playerkilled': "_NAME_ murio", // Sharkiller killed
	'healthchanged': "_NAME_\'s health changed to _AMOUNT_/20", // Sharkiller's health changed to 5/20
	'playerbanned': "_NAME_ was banned!", // Sharkiller was banned!
	'playerunbanned': "_NAME_ was unbanned!", // Sharkiller was unbanned!
	'ipbanned': "_IP_ was banned!", // 19.64.84.24 was banned!
	'ipunbanned': "_IP_ was unbanned!", // 19.64.84.24 was unbanned!
	'arrowshooted': "Arrow Shot!", 
	'fireballshooted': "Bola de fuego disparada!", 
	'throwsnowball': "Snowball throwed!",
	'throwegg': "Egg thrown!",
	'changename': "_OLD_\'s name changed to _NEW_", // Sharkiller's name changed to Peter
	'playerteleported': "Jugador Transportado",
	'langchanged': "Idioma Cambiado! Actualizando pagina...",
	'wlloaded': "Whitelist loaded!",
	'wladded': "Added to Whitelist!",
	'wlsaved': "Whitelist has been saved successfully!",
	///////////////////
	//	Errors
	///////////////////
	'badparameters': "Parametros incorrectos",
	'messageempty': "Mensaje vacio",
	'wladdfail': "Failed to add player to Whitelist!",
	'wlsavefail': "Failed to save Whitelist! Try again!",
	'playernotconnected': "Jugador desconectado",
	'playernotbanned': "Jugador no baneado",
	'ipnotbanned': "IP no baneada",
	'langnotfound': "Idioma no encontrado!"
};

///////////////////////////////////////////////
//
//   Language for login.html
//
///////////////////////////////////////////////

var langLogin = {
	'langmilkAdminLogin': "Iniciar Seccion en milkAdmin",
	'langUsername': "Usuario",
	'langPassword': "Contraseña",
	'langLogin': "Login"
};

var jsLogin = {
	'welcome': "Welcome! Loading page...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'invalidlogin': "Usuario o contraseña incorrectos"
};

///////////////////////////////////////////////
//
//   Language for register.html
//
///////////////////////////////////////////////

var langRegister = {
	'langCreateAnAccount': "Crear una cuenta",
	'langUsername': "Usuario",
	'langPassword': "Contraseña",
	'langCreateAccount': "Crear cuenta"
};

var jsRegister = {
	'created': "Cuenta creada! Cargando pagina...",
	'notadmin': "No se puede usar \"admin\" como usuario",
	'baduser': "Por favor ingresa un usuario y contraseña validos",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'error': "Usuario y contraseña incorrectos"
};

///////////////////////////////////////////////
//
//   Language for startServer.html
//
///////////////////////////////////////////////

var langStart = {
	'langStartServer': "Iniciar servidor"
};

///////////////////////////////////////////////
//
//   Language for wait.html
//
///////////////////////////////////////////////

var langWait = {
	'langPleaseWait20Seconds': "Por favor espere 20 segundos"
};

///////////////////////////////////////////////
//
//   Language for backup.html
//
///////////////////////////////////////////////

var langBackup = {
	'langStatus': "Haciendo copia de seguridad."
};

var jsBackup = {
	'Complete': "Respaldo Completo! Empezando el servidor.",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again"
};