/**
	milkAdmin - WebAdministrator of Minecraft Server for Bukkit
    Copyright (C) 2010-2011  Alejandro Barreiro (Sharkiller)
**/
/*	
    This file is part of milkAdmin.

    This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
	To view a copy of this license, visit http'://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to
	Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
*/

///////////////////////////////////////////////
//
//   Language for index.html
//
///////////////////////////////////////////////

var langIndex = {
	///////////////////
	//	Common
	///////////////////
	'lang1Yes': "Tak",
	'lang1No': "Nie",
	'lang1OK': "OK",
	'lang1Add': "Dodaj",
	'lang1Cancel': "Anuluj",
	'lang1Send': "Wyślij",
	'lang1Change': "Zmień",
	'lang1On': "Włącz",
	'lang1Off': "Wyłącz",
	'lang1ReloadList': "Przeładuj liste",
	'lang1IPAddress': "Adres IP",
	'lang1Player': "Gracz",
	'lang1Action': "Akcja",
	'lang1User': "Nazwa użytkownika",
	'lang1Password': "Hasło",
	///////////////////
	//	Header
	///////////////////
	'langAbout': "O wtyczce...",
	'langLogout': "Wyloguj",
	'langChooseLanguage': "Zmienić język ",
	'langTranslate': "Tłumacz na swój język",
	///////////////////
	//	Update Dialog
	///////////////////
	'langNewVersionAvailable': "Nowa wersja jest dostępna!",
	'langVersionAvailable': "milkAdmin v_VER_ is available", // milkAdmin v1.0 is available
	'langUpdateNow': "Czy chcesz aktualizować teraz??",
	///////////////////
	//	About Dialog
	///////////////////
	'langmilkAdmin': "O milkAdmin",
	'langDesign': "Design i Programowanie:",
	'langUpdates': "Aktualizacja:",
	'langThanks': "Podziękowania dla:",
	///////////////////
	//	Ban Dialog
	///////////////////
	'langBanOptions': "Opcje blokowania",
	'langKickPlayer': "Wyrzuć gracza",
	'langBanPlayerName': "Zablokuj gracza",
	'langBanIPAddress': "Zablokuj adres IP",
	'langCause': "Powód",
	///////////////////
	//	Main Menu
	///////////////////
	'langRestartServer': "Zrestartuj serwer",
	'langReloadServer': "Przeładuj serwer",
	'langBackupStart': "Uruchom Backup",
	'langSaveMap': "Zapisz świat",
	'langStopServer': "Zatrzymaj serwer",
	///////////////////
	//	Sub Menu
	///////////////////
	'langServerSM': "Serwer",
	'langConsoleSM': "Konsola",
	'langPluginsSM': "Wtyczki",
	'langBackupsSM': "Kopie zapasowe",
	'langPlayersSM': "Gracze",
	'langBanListSM': "Banlist",
	'langWhitelistSM': "Whitelist",
	///////////////////
	//	Server Info
	///////////////////
	'langLastRestart': "Ostatni restart",
	'langAmountPlayersOnline': "Liczba graczy Online",
	'langFreeMemory': "Wolna pamięć",
	'langUsedMemory': "Używana pamięć",
	'langTotalMemory': "Ilość pamięci",
	'langMaxMemory': "Maksymalna ilość pamięci",
	'langTitleMemory': "Memory Data - <b>Free Memory</b>: Show the amount of free memory in the Minecraft Server.<br><b>Used Memory</b>: Show the amount of used memory in the Minecraft Server.<br><b>Total Memory</b>: Show the total amount of memory that the Minecraft Server use right now.<br><b>Max Memory</b>: Show the maximum amount of memory that the Minecraft Server will attempt to use.",
	'langFreeSpace': "Wolne miejsce",
	'langUsedSpace': "Używane miejsce",
	'langTotalSpace': "Miejsce całkowite",
	'langTitleSpace': "Space Data - Based on &quot;Backup Folder&quot; directory.",
	'langServerVersion': "Wersja serwera",
	'langCraftbukkitBuild': "Craftbukkit Build",
	///////////////////
	//	Server Panel
	///////////////////
	//	Server Info
	///////////////////
	'langServerInfoSM': "Server Info",
	'langBroadcastMessage': "Broadcast Message",
	'langTitleBroadcastMessage': "Broadcast Message - Send a message to all players whitout tag.",
	'langLevelName': "Main Level Name",
	'langTitleLevelName': "The value will be used as world name and as folder name.<br>You may also copy your saved game folder here, and change the name to the same as that folder\'s to load it instead. ",
	'langMCIPPORT': "Minecraft Server IP and Port",
	'langTitleMCIPPORT': "<b>IP:</b> Set this if you want the server to bind to a particular IP. It is strongly recommended that you leave server-ip blank!<br><b>Port:</b> Changes the port the server is hosting on. This port must be forwarded if the server is going through a router.<br><b>Valid values:</b><ul><li><b>IP:</b> Blank, or the IP you want your server to run on.</li><li><b>Port:</b> A number between <b>1-65535</b>. Default: <b>25565</b><ul><li>Should be greater than 20000 to avoid conflicts with system reserved ports.</li></ul></li></ul>",
	'langMaxPlayers': "Max Players",
	'langTitleMaxPlayers': "The max numbers of players that can play on the server at the same time.<br><i>Note that if more players are on the server it will use more resources.</i><br><i>Note also, admin connections are not counted against the max players.</i><br><b>Valid values:</b><ul><li>A number between <b>0-255</b>.</li></ul>",
	'langViewDistance': "View Distance",
	'langTitleViewDistance': "The amount of chunks the server sends to the players.<br><b>Valid values:</b><ul><li>A number between <b>3-15</b>. Default: <b>10</b></li></ul>",
	'langHoldMessage': "Hold Message",
	'langTitleHoldMessage': "Message that MCSODRTK will display when Server is on Hold.<br><i>Needs MinecraftRemoteToolkit</i>",
	'langAllowNether': "Zezwól na Nether",
	'langTitleAllowNether': "Allows players to travel to the Nether.<ul><li><b>true</b> = The server will allow Portals to send players to the Nether.</li><li><b>false</b> = Portals will not travel to the Nether.</li></ul>",
	'langSpawnMonsters': "Pojawianie się potworów",
	'langTitleSpawnMonsters': "Set true if you want monsters to be spawned at night, false if you don\'t.<br><i>Tip: if you have major lag, turn this off.</i><ul><li><b>true</b> = Monsters will appear at night and in the dark.</li><li><b>false</b> = No monsters.</li></ul>",
	'langSpawnAnimals': "Pojawianie się zwierząt",
	'langTitleSpawnAnimals': "Animals will be able to spawn.<ul><li><b>true</b> = Animals spawn as normal.</li><li><b>false</b> = Animals will immediately vanish.</li></ul>",
	'langOnlineMode': "Online Mode",
	'langTitleOnlineMode': "Server checks connecting players against minecraft\'s account database.<br>Only set this to false if your server is not connected to the Internet.<ul><li><b>true</b> = The server will assume it has an Internet connection and check in minecraft.net every connecting player.</li><li><b>false</b> = The server will not attempt to check connecting players.</li></ul>",
	'langPVP': "Gracz vs Gracz (PVP)",
	'langTitlePVP': "Enable Player vs Player on the server.<br><i>Note: Hitting a player while having PvP set to false and having tamed wolfs will still cause the wolfs<br>attacking the attacked player.</i><ul><li><b>true</b> = Players will be able to kill each other.</li><li><b>false</b> = Players cannot kill other players.</li></ul>",
	'langAllowFlight': "Allow Flight",
	'langTitleAllowFlight': "Will allow users to use flight/no-clip on your server, if they have an mod that provides flight/no-clip installed.<ul><li><b>true</b> = Flight/no clip is allowed, and used if the player have a no-clip mod installed.</li><li><b>false</b> = Flight/no-clip is not allowed.</li></ul>",
	'langWhitelist': "Whitelist",
	'langTitleWhitelist': "Enable a white list on the server. With a white list enabled, users not on the white list will be unable to connect.<ul><li><b>true</b> = The file white-list.txt is used to generate the white list.</li><li><b>false</b> = No white list is used.</li></ul>",
	///////////////////
	//	Whitelist
	///////////////////
	'langWhitelistSM': "Whitelist",
	'langWLAddPlayer': "Dodaj gracza",
	'langWLDeleteSelected': "Skasuj zaznaczone",
	'langWLSaveChanges': "Zapisz zmiany",
	///////////////////
	//	Plugin Panel
	///////////////////
	'langEnablePlugin': "Włącz wtyczke",
	'langEnable': "Aktywuj",
	'langPluginName': "Nazwa wtyczki",
	'langVersion': "Wersja",
	'langReloadTheList': "Przeładuj serwer",
	///////////////////
	//	Backup Panel
	///////////////////
	'langChooseYourBackup': "Wybierz kopie zapasową",
	'langRestoreBackup': "Przywróć z kopii zapasowej",
	'langDeleteBackup': "Usuń kopie zapasową",
	'langBackupClear': "Remove previous folders before restoring the backup",
	///////////////////
	//	Players
	///////////////////
	'langUserManagement': "Zarządzanie graczem",
	'langIP': "IP",
	'langPort': "Port",
	'langKill': "Zabij",
	'langKick': "Wyrzuć",
	'langBanName': "Zablokuj",
	'langBanIP': "Zablokuj IP",
	'langAmount': "Ilość czasów",
	'langShootArrow': "Strzel strzałą",
	'langShootFireball': "Strzelić  kula ognia ",
	'langThrowEgg': "Rzuć jajkiem",
	'langThrowSnowball': "Rzuć śnieżką",
	'langTeleportToPlayer': "Teleportuj do gracza",
	'langTeleportToCoord': "Teleportuj na wspołrzędne",
	'langChangeName': "Zmień nazwę",
	///////////////////
	//	Ban List
	///////////////////
	'langCreateBan': "Zablokuj adres IP lub gracza",
	'langClearFilter': "Wyczyść filtr",
	///////////////////
	//	milkAdmin
	///////////////////
	'langRegisterAdmin': "Zarejestruj nowego administratora",
	'langCreateAdmin': "Stwórz administratora"
};

var jsIndex = {
	'sProcessing': "Przetwarzanie...",
	'sLengthMenu': "Pokaż _MENU_ pluginów", // Show 10 plugins
	'sZeroRecords': "Nie znaleziono wtyczek.",
	'sInfo': "Pokazane _START_->_END_ z _TOTAL_ pluginów", // Showing 1->10 of 17 plugins
	'sInfoEmpty': "Brak wtyczek do pokazania",
	'sInfoFiltered': "(filtrowane _MAX_ wtyczek)", // (filter of 17 plugins)
	'sSearch': "Szukaj wtyczki:",
	'sFirst': "Pierwsza",
	'sPrevious': "Poprzednia",
	'sNext': "Następna",
	'sLast': "Ostatnia",
	'ReloadServer': "Przeładowywanie serwera!",
	'RestartServer': "Restartowanie serwera!",
	'StopServer': "Zatrzymywanie serwera!",
	'EnablePlugin': "Aktywacja wtyczki!",
	'StartBackup': "Starting Backup!",
	'RTKNeeded': "You need the RemoteToolkit to use this function!",
	'NoUsersOnline': "Nie ma aktywnych graczy",
	'NoBackups': "There are no backups!",
	'activate': "Aktywacja",
	'deactivate': "Dezaktywacja",
	'unban': "Odblokowanie",
	'MustLogin': "You must login!",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'InvalidIP': "Nie prawidłowy adres IP.",
	'UpdateNow': "Aktualizuj teraz!",
	'later': "Potem..."
};

var jsAjax = {
	'accountcreated': "Konto stworzone!",
	'worldsaved': "Świat zapisany!",
	'messagesent': "Wiadomość wysłana",
	'broadcastedmessage': "Nadawanie wiadomości.",
	'forcestop': "Wymuszanie zatrzymanie serwera",
	'plugindisabled': "_NAME_ jest zablokowany", // PluginX's plugin disabled.
	'pluginenabled': "_NAME_ jest odblokowany", // PluginX's plugin enabled.
	'editedproperty': "Edited property",
	'worldbackedup': "Backed up World",
	'deletebackup': "Kopia zapasowa usunięta",
	'kickplayer': "_NAME_ został/a wyrzucony z serwera", // Sharkiller kicked from the server
	'itemsgiven': "_NAME_ dostał/a _AMOUNT_ _ITEM_", // Sharkiller was given 64 units of IRON
	'itemsremoved': "_NAME_ zabrano _AMOUNT_ _ITEM_", // Sharkiller removed 64 units of TNT
	'playerkilled': "_NAME_ zabity/a!", // Sharkiller killed
	'healthchanged': "_NAME_ jego/jej życie zostało zmienione na _AMOUNT_/20", // Sharkiller's health changed to 5/20
	'playerbanned': "_NAME_ został zablokowany!", // Sharkiller was banned!
	'playerunbanned': "_NAME_ został odblokowany!", // Sharkiller was unbanned!
	'ipbanned': "_IP_ został zablokowany!", // 19.64.84.24 was banned!
	'ipunbanned': "_IP_ został odblokowany!", // 19.64.84.24 was unbanned!
	'arrowshooted': "Strzał!", 
	'fireballshooted': "Strzelony kulą ognia", 
	'throwsnowball': "Rzucono śnieżką!",
	'throwegg': "Jajko rzucone!",
	'changename': "_OLD_ został zmieniony na _NEW_", // Sharkiller's name changed to Peter
	'playerteleported': "Przeteleportowano gracza",
	'langchanged': "Zmieniony język, restartowanie strony",
	'wlloaded': "Whitelist loaded!",
	'wladded': "Dodano do Whitelisty!",
	'wlsaved': "Whitelista została zapisana pomyślnie!",
	///////////////////
	//	Errors
	///////////////////
	'badparameters': "Zły parametr",
	'messageempty': "Pusta wiadomość",
	'wladdfail': "Failed to add player to Whitelist!",
	'wlsavefail': "Failed to save Whitelist! Try again!",
	'playernotconnected': "Gracz nie jest połączony",
	'playernotbanned': "Gracz nie jest zablokowany",
	'ipnotbanned': "IP not banned",
	'langnotfound': "Język nie znaleziony"
};

///////////////////////////////////////////////
//
//   Language for login.html
//
///////////////////////////////////////////////

var langLogin = {
	'langmilkAdminLogin': "Zaloguj się do milkAdmin",
	'langUsername': "Nazwa użytkownika",
	'langPassword': "Hasło",
	'langLogin': "Zaloguj"
};

var jsLogin = {
	'welcome': "Witaj! Ładowanie strony...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'invalidlogin': "Nie prawidłowa nazwa lub hasło!"
};

///////////////////////////////////////////////
//
//   Language for register.html
//
///////////////////////////////////////////////

var langRegister = {
	'langCreateAnAccount': "Tworzenie użytkownika",
	'langUsername': "Nazwa użytkownika",
	'langPassword': "Hasło",
	'langCreateAccount': "Stwórz użytkownika"
};

var jsRegister = {
	'created': "Konto stworzone! Ładowanie strony...",
	'notadmin': "Nie możesz użyć \"admin\" jako nazwy!",
	'baduser': "Wprowadź poprawną nazwe lub hasło",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again",
	'error': "Nie prawidłowa nazwa lub hasło!"
};

///////////////////////////////////////////////
//
//   Language for startServer.html
//
///////////////////////////////////////////////

var langStart = {
	'langStartServer': "Start Server"
};

///////////////////////////////////////////////
//
//   Language for wait.html
//
///////////////////////////////////////////////

var langWait = {
	'langPleaseWait20Seconds': "Proszę poczekaj 20 sekund"
};

///////////////////////////////////////////////
//
//   Language for backup.html
//
///////////////////////////////////////////////

var langBackup = {
	'langStatus': "Backing up"
};

var jsBackup = {
	'Complete': "Backup Complete! Starting Server...",
	'UnknownError': "Unknown Error! Try again!",
	'NotResponse': "Server not responding! Try again"
};