/**
	milkAdmin - WebAdministrator of Minecraft Server for Bukkit
    Copyright (C) 2010-2011  Alejandro Barreiro (Sharkiller)
**/
/*	
    This file is part of milkAdmin.

    This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
	To view a copy of this license, visit http'://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to
	Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
*/

///////////////////////////////////////////////
//
//   Language for index.html
//
///////////////////////////////////////////////

var langIndex = {
	///////////////////
	//	Common
	///////////////////
	'lang1Yes': "Oui",
	'lang1No': "Non",
	'lang1OK': "Ok",
	'lang1Add': "Ajouter",
	'lang1Cancel': "Annuler",
	'lang1Send': "Envoyer",
	'lang1Change': "Changer",
	'lang1On': "Activé",
	'lang1Off': "Désactivé",
	'lang1ReloadList': "Recharger la liste",
	'lang1IPAddress': "Adresse IP",
	'lang1Player': "Joueur",
	'lang1Action': "Action",
	'lang1User': "Nom d\'utilisateur",
	'lang1Password': "Mot de passe",
	///////////////////
	//	Header
	///////////////////
	'langAbout': "A propos...",
	'langLogout': "Déconnexion",
	'langChooseLanguage': "Choisissez une langue",
	'langTranslate': "Traduire vers votre langue",
	///////////////////
	//	Update Dialog
	///////////////////
	'langNewVersionAvailable': "Nouvelle Version Disponible",
	'langVersionAvailable': "milkAdmin v_VER_ is available", // milkAdmin v1.0 is available
	'langUpdateNow': "Voulez-vous mettre à jour maintenant ?",
	///////////////////
	//	About Dialog
	///////////////////
	'langmilkAdmin': "A propos de milkAdmin",
	'langDesign': "Design et programmation :",
	'langUpdates': "Mise à jour:",
	'langThanks': "Merci à:",
	///////////////////
	//	Ban Dialog
	///////////////////
	'langBanOptions': "Options Ban",
	'langKickPlayer': "Exclure un joueur",
	'langBanPlayerName': "Bannir le nom du joueur",
	'langBanIPAddress': "Bannir l\'adresse IP",
	'langCause': "À Cause de",
	///////////////////
	//	Main Menu
	///////////////////
	'langRestartServer': "Redémarrer le serveur ",
	'langReloadServer': "Recharger le serveur",
	'langBackupStart': "Commencer le Backup",
	'langSaveMap': "Sauvegarder le monde",
	'langStopServer': "Arrêter le serveur",
	///////////////////
	//	Sub Menu
	///////////////////
	'langServerSM': "Serveur",
	'langConsoleSM': "Console",
	'langPluginsSM': "Plugins",
	'langBackupsSM': "Sauvegardes",
	'langPlayersSM': "Joueurs",
	'langBanListSM': "Banlist",
	'langWhitelistSM': "Whitelist",
	///////////////////
	//	Server Info
	///////////////////
	'langLastRestart': "Dernier redémarrage",
	'langAmountPlayersOnline': "Aucun joueurs en ligne",
	'langFreeMemory': "Memoire libre",
	'langUsedMemory': "Mémoire utilisée",
	'langTotalMemory': "Mémoire Total",
	'langMaxMemory': "Mémoire Maximale",
	'langTitleMemory': "Memory Data - <b>Free Memory</b>: Show the amount of free memory in the Minecraft Server.<br><b>Used Memory</b>: Show the amount of used memory in the Minecraft Server.<br><b>Total Memory</b>: Show the total amount of memory that the Minecraft Server use right now.<br><b>Max Memory</b>: Show the maximum amount of memory that the Minecraft Server will attempt to use.",
	'langFreeSpace': "Espace libre",
	'langUsedSpace': "Espace utilisé",
	'langTotalSpace': "Espace total",
	'langTitleSpace': "Space Data - Based on &quot;Backup Folder&quot; directory.",
	'langServerVersion': "Version du serveur",
	'langCraftbukkitBuild': "Version Craftbukkit",
	///////////////////
	//	Server Panel
	///////////////////
	//	Server Info
	///////////////////
	'langServerInfoSM': "Infos Serveur",
	'langBroadcastMessage': "Envoyer un message au joueurs",
	'langTitleBroadcastMessage': "Broadcast Message - Send a message to all players whitout tag.",
	'langLevelName': "Nom du monde principal",
	'langTitleLevelName': "The value will be used as world name and as folder name.<br>You may also copy your saved game folder here, and change the name to the same as that folder\'s to load it instead. ",
	'langMCIPPORT': "IP et port du serveur MineCraft",
	'langTitleMCIPPORT': "<b>IP:</b> Set this if you want the server to bind to a particular IP. It is strongly recommended that you leave server-ip blank!<br><b>Port:</b> Changes the port the server is hosting on. This port must be forwarded if the server is going through a router.<br><b>Valid values:</b><ul><li><b>IP:</b> Blank, or the IP you want your server to run on.</li><li><b>Port:</b> A number between <b>1-65535</b>. Default: <b>25565</b><ul><li>Should be greater than 20000 to avoid conflicts with system reserved ports.</li></ul></li></ul>",
	'langMaxPlayers': "Nombre de joueurs maximum",
	'langTitleMaxPlayers': "The max numbers of players that can play on the server at the same time.<br><i>Note that if more players are on the server it will use more resources.</i><br><i>Note also, admin connections are not counted against the max players.</i><br><b>Valid values:</b><ul><li>A number between <b>0-255</b>.</li></ul>",
	'langViewDistance': "Distance de vue",
	'langTitleViewDistance': "The amount of chunks the server sends to the players.<br><b>Valid values:</b><ul><li>A number between <b>3-15</b>. Default: <b>10</b></li></ul>",
	'langHoldMessage': "Hold Message",
	'langTitleHoldMessage': "Message that MCSODRTK will display when Server is on Hold.<br><i>Needs MinecraftRemoteToolkit</i>",
	'langAllowNether': "Activer le Nether",
	'langTitleAllowNether': "Allows players to travel to the Nether.<ul><li><b>true</b> = The server will allow Portals to send players to the Nether.</li><li><b>false</b> = Portals will not travel to the Nether.</li></ul>",
	'langSpawnMonsters': "Apparition de monstres",
	'langTitleSpawnMonsters': "Set true if you want monsters to be spawned at night, false if you don\'t.<br><i>Tip: if you have major lag, turn this off.</i><ul><li><b>true</b> = Monsters will appear at night and in the dark.</li><li><b>false</b> = No monsters.</li></ul>",
	'langSpawnAnimals': "Apparition d\'animaux",
	'langTitleSpawnAnimals': "Animals will be able to spawn.<ul><li><b>true</b> = Animals spawn as normal.</li><li><b>false</b> = Animals will immediately vanish.</li></ul>",
	'langOnlineMode': "Mode en ligne (vérifier les noms)",
	'langTitleOnlineMode': "Server checks connecting players against minecraft\'s account database.<br>Only set this to false if your server is not connected to the Internet.<ul><li><b>true</b> = The server will assume it has an Internet connection and check in minecraft.net every connecting player.</li><li><b>false</b> = The server will not attempt to check connecting players.</li></ul>",
	'langPVP': "Joueur contre Joueur (PVP)",
	'langTitlePVP': "Enable Player vs Player on the server.<br><i>Note: Hitting a player while having PvP set to false and having tamed wolfs will still cause the wolfs<br>attacking the attacked player.</i><ul><li><b>true</b> = Players will be able to kill each other.</li><li><b>false</b> = Players cannot kill other players.</li></ul>",
	'langAllowFlight': "Autoriser le Vol",
	'langTitleAllowFlight': "Will allow users to use flight/no-clip on your server, if they have an mod that provides flight/no-clip installed.<ul><li><b>true</b> = Flight/no clip is allowed, and used if the player have a no-clip mod installed.</li><li><b>false</b> = Flight/no-clip is not allowed.</li></ul>",
	'langWhitelist': "Whitelist",
	'langTitleWhitelist': "Enable a white list on the server. With a white list enabled, users not on the white list will be unable to connect.<ul><li><b>true</b> = The file white-list.txt is used to generate the white list.</li><li><b>false</b> = No white list is used.</li></ul>",
	///////////////////
	//	Whitelist
	///////////////////
	'langWhitelistSM': "Whitelist",
	'langWLAddPlayer': "Ajouter un joueur",
	'langWLDeleteSelected': "Supprimer sélectionnés",
	'langWLSaveChanges': "Sauvegarder les changements",
	///////////////////
	//	Plugin Panel
	///////////////////
	'langEnablePlugin': "Activer le plugin",
	'langEnable': "Activer",
	'langPluginName': "Nom du plugin",
	'langVersion': "Version",
	'langReloadTheList': "Recharger la liste",
	///////////////////
	//	Backup Panel
	///////////////////
	'langChooseYourBackup': "Choisissez votre Backup",
	'langRestoreBackup': "Restaurez le Backup",
	'langDeleteBackup': "Supprimer le Backup",
	'langBackupClear': "Remove previous folders before restoring the backup",
	///////////////////
	//	Players
	///////////////////
	'langUserManagement': "Gestion des utilisateurs",
	'langIP': "IP",
	'langPort': "Port",
	'langKill': "Tuer",
	'langKick': "Exclure",
	'langBanName': "Bannir",
	'langBanIP': "Bannir l\'IP",
	'langAmount': "Durée",
	'langShootArrow': "Tirer une fleche",
	'langShootFireball': "Envoyer une boule de feu",
	'langThrowEgg': "Jeter un Oeuf",
	'langThrowSnowball': "Jeter une boule de neige",
	'langTeleportToPlayer': "Teleporter au joueur",
	'langTeleportToCoord': "Téléporter aux coordonnées",
	'langChangeName': "Changer le Nom",
	///////////////////
	//	Ban List
	///////////////////
	'langCreateBan': "Bannir l\'Adresse IP ou le Pseudo",
	'langClearFilter': "Nettoyer le Filtre",
	///////////////////
	//	milkAdmin
	///////////////////
	'langRegisterAdmin': "Enregistré un nouvelle administrateur",
	'langCreateAdmin': "Créer un Administrateur  "
};

var jsIndex = {
	'sProcessing': "En cours de Traitement...",
	'sLengthMenu': "Afficher le menu des plugins", // Show 10 plugins
	'sZeroRecords': "Aucun plugins trouvé.",
	'sInfo': "Liste _END_ _START_-> plugins de _TOTAL_", // Showing 1->10 of 17 plugins
	'sInfoEmpty': "Aucuns plugins à voir ",
	'sInfoFiltered': "(filtre du maximum de plugins)", // (filter of 17 plugins)
	'sSearch': "Recherche d\'un plugin :",
	'sFirst': "Premier",
	'sPrevious': "Précédent ",
	'sNext': "Suivant",
	'sLast': "Dernier",
	'ReloadServer': "Rechargement du Serveur!",
	'RestartServer': "Redémarrage du serveur!",
	'StopServer': "Arrêt du serveur!",
	'EnablePlugin': "Plugin activé!",
	'StartBackup': "Démarrage de la sauvegarde",
	'RTKNeeded': "You need the RemoteToolkit to use this function!",
	'NoUsersOnline': "Aucun joueurs en ligne",
	'NoBackups': "Il n\'y a pas de sauvegardes",
	'activate': "Activé",
	'deactivate': "Désactiver",
	'unban': "Débannir",
	'MustLogin': "Vous devez vous connecter !",
	'UnknownError': "Erreur inconnue! Essayez à nouveau",
	'NotResponse': "Le serveur ne répond pas ! Veuillez ré-essayez !",
	'InvalidIP': "Adresse IP non valide.",
	'UpdateNow': "Mettre à jour maintenant",
	'later': "Plus Tard"
};

var jsAjax = {
	'accountcreated': "Compte crée!",
	'worldsaved': "Monde Sauvegardé!",
	'messagesent': "Message envoyé ",
	'broadcastedmessage': "Diffusion du Message",
	'forcestop': "Arrêt Forcé",
	'plugindisabled': "_NAME_ désactivé !", // PluginX's plugin disabled.
	'pluginenabled': "_NAME_ activé !", // PluginX's plugin enabled.
	'editedproperty': "Edité la Propriété",
	'worldbackedup': "Monde Sauvegardé",
	'deletebackup': "Monde Supprimé",
	'kickplayer': "_NAME_ éjecté du serveur", // Sharkiller kicked from the server
	'itemsgiven': "_NAME_ a été donnée _AMOUNT_ unités de _ITEM_", // Sharkiller was given 64 units of IRON
	'itemsremoved': "_NAME_ retiré _AMOUNT_ unités de _ITEM_", // Sharkiller removed 64 units of TNT
	'playerkilled': "_NAME_ Tué", // Sharkiller killed
	'healthchanged': "La santé de _NAME_\'s changé vers _AMOUNT_/20", // Sharkiller's health changed to 5/20
	'playerbanned': "_NAME_ a été banni!", // Sharkiller was banned!
	'playerunbanned': "_NAME_ n\'est plus banni !", // Sharkiller was unbanned!
	'ipbanned': "_IP_ été bannie!", // 19.64.84.24 was banned!
	'ipunbanned': "_IP_ a été débanni !", // 19.64.84.24 was unbanned!
	'arrowshooted': "Arrow Shot!", 
	'fireballshooted': "Boule de feu lancée!", 
	'throwsnowball': "Boule ne neige jetée!",
	'throwegg': "Egg thrown!",
	'changename': "_OLD_\'s changé de nom pour _NEW_", // Sharkiller's name changed to Peter
	'playerteleported': "Joueur téléporté",
	'langchanged': "Langue changée! Actualisation de la page.",
	'wlloaded': "Whitelist chargée !",
	'wladded': "Ajouté à la Whithelist !",
	'wlsaved': "La Whiteliste à bien été sauvegardée !",
	///////////////////
	//	Errors
	///////////////////
	'badparameters': "Mauvais paramètres",
	'messageempty': "Message Vide",
	'wladdfail': "Echec lors de l\'ajout d\'un joueur à la Whitelist !",
	'wlsavefail': "Failed to save Whitelist! Try again!",
	'playernotconnected': "Joueur non connecté",
	'playernotbanned': "Player n\'est pas banni",
	'ipnotbanned': "IP n\'est pas banni",
	'langnotfound': "La langue n\'a pas été trouvée"
};

///////////////////////////////////////////////
//
//   Language for login.html
//
///////////////////////////////////////////////

var langLogin = {
	'langmilkAdminLogin': "Connectez-vous au milkAdmin",
	'langUsername': "Nom d\'utilisateur",
	'langPassword': "Mot de passe",
	'langLogin': "Connexion"
};

var jsLogin = {
	'welcome': "Bienvenue ! Chargement de la page...",
	'UnknownError': "Erreur inconnue! Essayez à nouveau",
	'NotResponse': "Le serveur ne répond pas ! Veuillez ré-essayez !",
	'invalidlogin': "Nom d\'utilisateur et mot de passe invalide!"
};

///////////////////////////////////////////////
//
//   Language for register.html
//
///////////////////////////////////////////////

var langRegister = {
	'langCreateAnAccount': "Créer un compte",
	'langUsername': "Nom d\'utilisateur",
	'langPassword': "Mot de passe",
	'langCreateAccount': "Créer un compte"
};

var jsRegister = {
	'created': "Compte crée! Chargement...",
	'notadmin': "Vous ne pouvez pas utiliser admin comme pseudo",
	'baduser': "Veuillez entrer un nom d\'utilisateur et un mot de passe valide",
	'UnknownError': "Erreur inconnue! Essayez à nouveau",
	'NotResponse': "Le serveur ne répond pas ! Veuillez ré-essayez !",
	'error': "Nom d\'utilisateur et mot de passe invalide!"
};

///////////////////////////////////////////////
//
//   Language for startServer.html
//
///////////////////////////////////////////////

var langStart = {
	'langStartServer': "Démarrer le serveur"
};

///////////////////////////////////////////////
//
//   Language for wait.html
//
///////////////////////////////////////////////

var langWait = {
	'langPleaseWait20Seconds': "Attendez 20 secondes s\'il vous plait..."
};

///////////////////////////////////////////////
//
//   Language for backup.html
//
///////////////////////////////////////////////

var langBackup = {
	'langStatus': "Sauvegarde en cours"
};

var jsBackup = {
	'Complete': "Sauvegarde terminée ! Démarrage du serveur",
	'UnknownError': "Erreur inconnue! Essayez à nouveau",
	'NotResponse': "Le serveur ne répond pas ! Veuillez ré-essayez !"
};